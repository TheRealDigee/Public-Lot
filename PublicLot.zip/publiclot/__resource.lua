this_is_a_map 'yes'

--Redesigned by Digetal#3203